# Signature of the current package.
m4_define([AT_PACKAGE_NAME],      [GNU cflow])
m4_define([AT_PACKAGE_TARNAME],   [cflow])
m4_define([AT_PACKAGE_VERSION],   [1.8])
m4_define([AT_PACKAGE_STRING],    [GNU cflow 1.8])
m4_define([AT_PACKAGE_BUGREPORT], [bug-cflow@gnu.org])
